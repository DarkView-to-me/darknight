# enigmas.com
Uma série de enigmas como teste
