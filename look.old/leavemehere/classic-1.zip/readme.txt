﻿=== Original Classic Win2000/XP 2 Cursor Set ===

By: TuberMine2001 (http://www.rw-designer.com/user/73532)

Download: http://www.rw-designer.com/cursor-set/classic-1

Author's description:

MEGA PACK animated cursors: https://drive.google.com/file/d/1gAj9HEk9zYX4z1VSYPuEP281OJmQJzCn/view?usp=sharing
...........................
Original sliders taken from Windows XP.

With a software called Resource Hacker,
which also allows you to extract the cursors within the DLL extension.

Then the default original cursors are on ../WINDOWS/system32/user32.dll

Forum discussion: http://www.rw-designer.com/forum/1553

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.